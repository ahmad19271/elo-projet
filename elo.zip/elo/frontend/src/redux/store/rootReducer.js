import { combineReducers } from "@reduxjs/toolkit";
import { reducer as userReducer } from "../slices/userSlice";
import { reducer as productReducer } from "../slices/productSlice";
import { reducer as orderReducer } from "../slices/orderSlice";
import { reducer as cartReducer } from "../slices/cartSlice";

// Combine reducers into a root reducer
export const rootReducer = combineReducers({
  user: userReducer,      // User-related reducer
  product: productReducer, // Product-related reducer
  order: orderReducer,     // Order-related reducer
  cart: cartReducer,       // Cart-related reducer
});
