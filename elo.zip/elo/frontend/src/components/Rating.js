import React from "react";
import { Typography, Box } from "@material-ui/core";
import { Star, StarHalf, StarBorder } from "@material-ui/icons";

function Rating({ value, text, color }) {
  return (
    <>
      <Box display="flex" alignItems="center">
        {[1, 2, 3, 4, 5].map((index) => (
          <Box key={index} mr={1}>
            {value >= index ? (
              <Star style={{ color }} fontSize="small" />
            ) : value >= index - 0.5 ? (
              <StarHalf style={{ color }} fontSize="small" />
            ) : (
              <StarBorder style={{ color }} fontSize="small" />
            )}
          </Box>
        ))}
      </Box>
      <Typography variant="subtitle2" color="textSecondary">
        {text ? text : ""}
      </Typography>
    </>
  );
}

export default Rating;
