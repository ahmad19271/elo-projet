import React, { useEffect } from "react";
import { Carousel, Image } from "react-bootstrap";
import { useDispatch, useSelector } from "react-redux";
import { Link } from "react-router-dom";
import Loader from "./Loader";
import Message from "./Message";
import { fetchTopRatedProducts } from "../redux/slices/productSlice";

function ProductCarousel() {
  const dispatch = useDispatch();
  const topRatedProducts = useSelector((state) => state.product.topRatedProducts);
  const { error, loading, products } = topRatedProducts;

  useEffect(() => {
    dispatch(fetchTopRatedProducts());
  }, [dispatch]);

  return loading ? (
    <Loader />
  ) : error ? (
    <Message variant="danger">{error}</Message>
  ) : (
    <Carousel style={{ height: "400px", margin: "20px 0" }} pause="hover" interval={5000}>
      {products.map((product) => (
        <Carousel.Item key={product._id}>
          <Link to={`/product/${product._id}`} style={{ textDecoration: "none" }}>
            <Image src={product.image} alt={product.name} fluid style={{ height: "300px", borderRadius: "10px" }} />
            <Carousel.Caption style={{ backgroundColor: "#4CAF50", padding: "10px", borderRadius: "0 0 10px 10px" }}>
              <h4 style={{ color: "#fff" }}>{product.name}</h4>
              <p style={{ color: "#fff" }}>RS{product.price}</p>
            </Carousel.Caption>
          </Link>
        </Carousel.Item>
      ))}
    </Carousel>
  );
}

export default ProductCarousel;
