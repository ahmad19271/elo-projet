import React from "react";
import { Container, Grid, Typography } from "@material-ui/core";
import { makeStyles } from "@material-ui/core/styles";

const useStyles = makeStyles((theme) => ({
  footer: {
    backgroundColor: "#FFA500",  // Change the background color
    padding: theme.spacing(2),  // Add padding to the footer
    marginTop: theme.spacing(4),  // Add some space at the top
    color: theme.palette.common.white,  // Change the text color to white
  },
}));

function Footer() {
  const classes = useStyles();

  return (
    <footer className={classes.footer}>
      <Container>
        <Grid container justifyContent="center">
          <Grid item>
            <Typography variant="body1" align="center">
              &copy; 2024 ELO. All rights reserved.
            </Typography>
          </Grid>
        </Grid>
      </Container>
    </footer>
  );
}

export default Footer;
