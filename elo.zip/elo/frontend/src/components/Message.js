import MuiAlert from '@mui/material/Alert';
import { styled } from '@mui/material/styles';

const StyledAlert = styled(MuiAlert)(({ theme, variant }) => ({
  backgroundColor: theme.palette.secondary.main, // Change the background color
  color: theme.palette.primary.contrastText, // Change the text color
  borderRadius: theme.shape.borderRadius, // Add border radius for a rounded look
  boxShadow: `0 4px 8px ${theme.palette.grey[400]}`, // Add a subtle box shadow
  padding: theme.spacing(2), // Add padding
}));

export default function Message({ variant, children }) {
  return (
    <StyledAlert variant={variant} severity={variant}>
      {children}
    </StyledAlert>
  );
}
