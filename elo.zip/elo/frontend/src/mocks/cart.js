import axios from "axios";

class CartAPI {
  async fetchProduct(productId) {
    try {
      // Simulate delay for demonstration purposes (remove in production)
      await new Promise(resolve => setTimeout(resolve, 1000));

      // Actual API call
      const { data } = await axios.get(`/api/products/${productId}`);
      return data;
    } catch (error) {
      throw error;
    }
  }
}

const cartAPI = new CartAPI();

export default cartAPI;
