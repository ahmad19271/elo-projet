import React, { useEffect } from "react";
import { Row, Col, ListGroup, Card } from "react-bootstrap";
import { useDispatch, useSelector } from "react-redux";
import { payOrder } from "../redux/slices/orderSlice";
import Message from "../components/Message";
import Loader from "../components/Loader";

function OrderScreen({ history }) {
  const dispatch = useDispatch();
  const order = useSelector((state) => state.order);
  const { orderDetails, error, loading } = order;
  const userLogin = useSelector((state) => state.user);
  const { userDetails } = userLogin;

  useEffect(() => {
    if (!userDetails) {
      history.push("/login");
    } else if (!orderDetails.isPaid) {
      // You can add any necessary logic here for handling unpaid orders
    }
  }, [dispatch, orderDetails, history, userDetails]);

  const calculateItemsPrice = () => {
    if (
      orderDetails.orderItems &&
      orderDetails.orderItems.length > 0
    ) {
      return orderDetails.orderItems.reduce((total, item) => {
        const itemPrice = parseFloat(item.price) * item.qty;
        return total + itemPrice;
      }, 0);
    }
    return 0;
  };

  const itemsPrice = calculateItemsPrice();

  return loading ? (
    <Loader />
  ) : error ? (
    <Message variant="danger">{error}</Message>
  ) : (
    <div>
      <h1>Order: {orderDetails._id}</h1>
      <Row>
        <Col md={8}>
          <ListGroup variant="flush">
            {/* ... existing code ... */}
            <ListGroup.Item>
              <h2>Order Items</h2>
              {orderDetails.orderItems.length === 0 ? (
                <Message variant="info">Order is empty</Message>
              ) : (
                <ListGroup variant="flush">
                  {orderDetails.orderItems.map((item, index) => (
                    <ListGroup.Item key={index}>
                      {/* ... existing code ... */}
                    </ListGroup.Item>
                  ))}
                </ListGroup>
              )}
            </ListGroup.Item>
          </ListGroup>
        </Col>

        <Col md={4}>
          <Card>
            <ListGroup variant="flush">
              <ListGroup.Item>
                <h2>Order Summary</h2>
              </ListGroup.Item>

              <ListGroup.Item>
                <Row>
                  <Col>Products Cost:</Col>
                  <Col>RS{itemsPrice}</Col>
                </Row>
              </ListGroup.Item>

              <ListGroup.Item>
                {/* ... existing code ... */}
              </ListGroup.Item>

              <ListGroup.Item>
                <Row>
                  <Col>Total:</Col>
                  <Col>Rs{orderDetails.totalPrice}</Col>
                </Row>
              </ListGroup.Item>
            </ListGroup>
          </Card>
        </Col>
      </Row>
    </div>
  );
}

export default OrderScreen;
